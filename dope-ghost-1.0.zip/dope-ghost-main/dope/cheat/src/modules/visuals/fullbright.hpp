#pragma once
#ifndef MODULES_FULLBRIGHT_H
#define MODULES_FULLBRIGHT_H

namespace modules {
	namespace fullbright {
		void thread();
	}
}

#endif // MODULES_FULLBRIGHT_H