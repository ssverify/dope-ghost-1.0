#pragma once
#ifndef MODULES_VELOCITY_H
#define MODULES_VELOCITY_H

namespace modules {
	namespace velocity {
		void thread();
	}
}

#endif // MODULES_VELOCITY_H