#pragma once
#ifndef MODULES_AIMASSIST_H
#define MODULES_AIMASSIST_H

namespace modules {
	namespace aimassist {
		void thread();
	}
}

#endif // MODULES_AIMASSIST_H