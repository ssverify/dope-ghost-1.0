#pragma once
#ifndef MODULES_AUTOCLICKER_H
#define MODULES_AUTOCLICKER_H

namespace modules {
	namespace autoclicker {
		void thread();
	}
}

#endif // MODULES_AUTOCLICKER_H