#pragma once
#ifndef MODULES_REACH_H
#define MODULES_REACH_H

namespace modules {
	namespace reach {
		void thread();
	}
}

#endif // MODULES_REACH_H