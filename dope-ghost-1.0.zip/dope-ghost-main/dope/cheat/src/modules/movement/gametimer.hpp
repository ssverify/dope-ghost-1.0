#pragma once
#ifndef MODULES_TIMER_H
#define MODULES_TIMER_H

namespace modules {
	namespace game_timer {
		void thread();
	}
}

#endif // MODULES_TIMER_H