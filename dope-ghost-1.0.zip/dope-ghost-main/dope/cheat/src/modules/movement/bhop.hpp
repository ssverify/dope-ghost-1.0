#pragma once
#ifndef MODULES_BHOP_H
#define MODULES_BHOP_H

namespace modules {
	namespace bhop {
		void thread();
	}
}

#endif // MODULES_BHOP_H