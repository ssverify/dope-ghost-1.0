#pragma once
#ifndef MODULES_THROWPOT_H
#define MODULES_THROWPOT_H

namespace modules {
	namespace throwpot {
		void thread();
	}
}

#endif // MODULES_THROWPOT_H