#pragma once
#ifndef MODULES_SETTINGS_H
#define MODULES_SETTINGS_H

namespace modules {
	namespace misc_settings {
		void thread();
	}
}

#endif // MODULES_SETTINGS_H