#pragma once
#ifndef MODULES_DESTRUCT_H
#define MODULES_DESTRUCT_H

namespace modules {
	namespace selfdestruct {
		void close();
	}
}

#endif // MODULES_DESTRUCT_H